# Big Fun 🎉

This is the **Big Fun Flutter App Project**.

## Features
- Splash Screen with logo
- Login Screen (placeholder)
- Voice Room Screen (placeholder)

## Build Instructions

### Codemagic (Recommended)
1. Upload this ZIP file directly to [Codemagic](https://codemagic.io).
2. Codemagic will detect `codemagic.yaml` and automatically build your APK.
3. Once build is complete, download the APK from Codemagic dashboard.

### Local (Optional)
If you want to build locally:
```bash
flutter pub get
flutter build apk --release
```
The APK will be in `build/app/outputs/flutter-apk/app-release.apk`.

---
Enjoy 🚀


## Notes
- `codemagic.yaml` will run `flutter_launcher_icons` to generate Android launcher icons from `assets/images/logo.png` before building the APK.
- Codemagic: upload this ZIP and the build will run automatically. You will still need to configure code signing in Codemagic if you want a release-signed APK.
